#!/usr/bin/env python3

import sys

for line in sys.stdin:
    # For every line, output the key-value pair ("line", 1)
    print('%s\t%s' % ("line", 1))
